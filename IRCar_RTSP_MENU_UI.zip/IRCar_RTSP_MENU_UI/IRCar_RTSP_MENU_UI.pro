QT       += core gui network svg

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

# The following define makes your compiler emit warnings if you use
# any Qt feature that has been marked deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

# 添加 OpenCV 头文件路径
INCLUDEPATH += /usr/include/opencv4

# 添加 OpenCV 库路径
LIBS += -L/usr/lib/x86_64-linux-gnu

# 链接 OpenCV 库
LIBS += -lopencv_core -lopencv_imgcodecs -lopencv_highgui -lopencv_imgproc

# You can also make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    gamepadreader.cpp \
    hk_rtsp.cpp \
    main.cpp \
    mainwindow.cpp \
    splashscreen.cpp \
    subwindows.cpp

HEADERS += \
    HCNetSDK.h \
    gamepadreader.h \
    hk_rtsp.h \
    mainwindow.h \
    splashscreen.h \
    subwindows.h

FORMS += \
    mainwindow.ui \
    subwindows.ui


qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

unix:!macx: LIBS += -L$$PWD/SDK/lib/ -lhcnetsdk

INCLUDEPATH += $$PWD/SDK/include
DEPENDPATH += $$PWD/SDK/include

INCLUDEPATH += $$PWD/SDK/lib
DEPENDPATH += $$PWD/SDK/lib

LIBS += -L/usr/local/lib \
        -lopencv_core \
        -lopencv_highgui \
        -lopencv_imgproc \
        -lopencv_videoio \
        -lopencv_imgcodecs

unix:!macx: LIBS += -L$$PWD/SDK/lib/ -lhcnetsdk

INCLUDEPATH += $$PWD/SDK/include
DEPENDPATH += $$PWD/SDK/include

RESOURCES += \
    images.qrc

QMAKE_RPATHDIR += /home/qin/qt_project/IRCar_RTSP_MENU_UI/SDK/lib

INCLUDEPATH += /usr/include/qwt-qt5 /usr/include/qwt
LIBS += -L/usr/lib/x86_64-linux-gnu -lqwt-qt5

