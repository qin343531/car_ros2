#ifndef GAMEPADREADER_H
#define GAMEPADREADER_H

#include <string>
#include <vector>
#include <linux/joystick.h>
#include <sys/select.h>
#include <cstdlib>  // 添加abs()函数支持
#include <fcntl.h>  // open()需要的头文件
#include <unistd.h> // close()需要的头文件

class GamepadReader {
public:
    explicit GamepadReader(const std::string& device_path);
    ~GamepadReader();

    void readButtons();
    std::vector<int> returnButtons();
    void closeDevice();
    int getAxisValue(int axis); // 获取指定轴的值
    bool hasNewEvent(); // 添加新方法检查是否有新事件
    bool readNextEvent(); // 添加新方法读取下一个事件
    std::string getPadState(); // 添加新方法用于获取手柄状态

//    // 状态码定义
//    static constexpr int STATE_RESET = 0;
//    static constexpr int STATE_LEFT = 17;
//    static constexpr int STATE_RIGHT = 18;
//    static constexpr int STATE_UP = 19;
//    static constexpr int STATE_DOWN = 20;
//    static constexpr int STATE_LEFT_TURN = 21;
//    static constexpr int STATE_RIGHT_TURN = 22;

    std::vector<int> returnStickState(); // 添加新方法

    struct StickMap {
        int lx = 0;
        int ly = 0;
        int rx = 0;
        int ry = 0;
        int a = 0;   // A按键状态
        int b = 0;   // B按键状态
        int x = 0;   // X按键状态
        int y = 0;   // Y按键状态
    };

    // 打开设备（返回是否成功）
    bool openDevice()
    {
        if (!devicePath.empty()) {
            fd = open(devicePath.c_str(), O_RDONLY | O_NONBLOCK);
        }
        return fd >= 0;
    }

    // 新增：检查设备是否已打开
    bool isDeviceOpen() const
    {
        return fd >= 0;
    }

private:
    std::string device_path_;
    int device_fd_;
    std::vector<int> axes; // 轴的值现在初始化为0
    struct js_event current_event_; // 添加存储当前事件的变量
    StickMap map_;
    void updateMap(const js_event& js);  // 添加updateMap方法声明

    int fd; // 设备文件描述符
    std::string devicePath; // 设备路径
};

#endif //
