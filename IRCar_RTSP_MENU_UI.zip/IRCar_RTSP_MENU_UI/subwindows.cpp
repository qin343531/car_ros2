#include "subwindows.h"
#include "ui_subwindows.h"
#include "mainwindow.h"
#include <QTimer>

Subwindows::Subwindows(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Subwindows)
{
    ui->setupUi(this);
    // ====================== 初始化直方图 ======================
    m_histogram = new QwtPlotHistogram();

    // 设置柱子颜色
    QwtColumnSymbol *symbol = new QwtColumnSymbol(QwtColumnSymbol::Box);
    symbol->setPalette(QColor(50, 150, 255));
    m_histogram->setSymbol(symbol);

    // 绑定到 plot
    m_histogram->attach(ui->qwtPlot);

    ui->qwtPlot->setTitle("空气质量实时数据");
    ui->qwtPlot->setTitle("CO₂  甲醛  TVOC  PM2.5  PM10  温度  湿度");

    // 4. 设置 X / Y 轴单位标题
    ui->qwtPlot->setAxisTitle(QwtPlot::xBottom, "监测项目");
    ui->qwtPlot->setAxisTitle(QwtPlot::yLeft, "数值(ppm/ppb/μg/m³/℃/%RH)");

    // ====================== 设置坐标轴范围 ======================
    ui->qwtPlot->setAxisScale(QwtPlot::yLeft, 0, 500);  // Y轴 0~500
    ui->qwtPlot->setAxisScale(QwtPlot::xBottom, 0, 7);   // X轴 7根柱子

    // 模拟数据
    //updateChart();

    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Subwindows::updateChart);
    timer->start(1000);
}

Subwindows::~Subwindows()
{
    delete ui;
}

void Subwindows::updateChart()
{
    QVector<QwtIntervalSample> samples;

    // 【我加的】先判断主窗口是否有效，再拿真实数据
    double d[7] = {0};
    if (mainWin) {
        d[0] = mainWin->m702_data[0];
        d[1] = mainWin->m702_data[1];
        d[2] = mainWin->m702_data[2];
        d[3] = mainWin->m702_data[3];
        d[4] = mainWin->m702_data[4];
        d[5] = mainWin->m702_data[5];
        d[6] = mainWin->m702_data[6];
    }

    //阈值判断（超标变红）
    bool warning = (d[0]>400) || (d[1]>100) || (d[2]>100) ||
                   (d[3]>75) || (d[4]>150) || (d[5]>40) || (d[6]>80);

    //设置颜色：超标红，正常蓝
    QwtColumnSymbol *symbol = new QwtColumnSymbol(QwtColumnSymbol::Box);
    if (warning) {
        symbol->setPalette(Qt::red);
    } else {
        symbol->setPalette(QColor(50, 150, 255));
    }
    m_histogram->setSymbol(symbol);

    samples << QwtIntervalSample(d[0], 0, 1)   // CO2
            << QwtIntervalSample(d[1], 1, 2)   // HCHO
            << QwtIntervalSample(d[2], 2, 3)   // TVOC
            << QwtIntervalSample(d[3], 3, 4)   // PM2.5
            << QwtIntervalSample(d[4], 4, 5)   // PM10
            << QwtIntervalSample(d[5], 5, 6)   // 温度
            << QwtIntervalSample(d[6], 6, 7);  // 湿度

    m_histogram->setSamples(samples);
    ui->qwtPlot->replot();
}
