#include "subwindows.h"
#include "ui_subwindows.h"
#include "mainwindow.h"
#include <QTimer>

// 自定义 X 轴名称（关键！）
class MyScaleDraw : public QwtScaleDraw
{
public:
    QwtText label(double v) const override
    {
        int index = qRound(v);
        QStringList names = {"CO₂", "甲醛", "TVOC", "PM2.5", "PM10", "温度", "湿度"};

        if (index >= 0 && index < names.size())
            return  QwtText(names[index]);
        else
            return QwtText("");
    }
};

Subwindows::Subwindows(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Subwindows)
{
    ui->setupUi(this);
    mainWin = (MainWindow*)parent;

    // 图表样式
    ui->qwtPlot->setTitle("空气质量实时数据");
    ui->qwtPlot->setAxisTitle(QwtPlot::xBottom, "监测项目");
    ui->qwtPlot->setAxisTitle(QwtPlot::yLeft, "数值");
    ui->qwtPlot->setAxisScale(QwtPlot::yLeft, 0, 1000);
    ui->qwtPlot->setAxisScale(QwtPlot::xBottom, 0, 7);
    ui->qwtPlot->setAxisScaleDraw(QwtPlot::xBottom, new MyScaleDraw());

    //ui->qwtPlot->enableAxis(QwtPlot::xBottom, false);

    // 定时器 1秒刷新
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Subwindows::updateChart);
    timer->start(1000);
}

Subwindows::~Subwindows()
{
    delete ui;
}

// ===================== 正确、稳定、单柱变色 =====================
void Subwindows::updateChart()
{
    double d[7];
    for (int i = 0; i < 7; i++)
        d[i] = m702_datasub[i];

    // 阈值（根据你的数据单位设置）
    double limits[7] = {
        400,   // CO2
        80,    // 甲醛
        600,   // TVOC
        75,    // PM2.5
        150,   // PM10
        40,    // 温度
        80     // 湿度
    };

    // 清空旧柱子
    // ===================== 关键：一次性清空所有柱子 + 文字 =====================
    ui->qwtPlot->detachItems(QwtPlotItem::Rtti_PlotHistogram);
    ui->qwtPlot->detachItems(QwtPlotItem::Rtti_PlotMarker);

    // 7 根独立柱子，独立颜色
    for (int i = 0; i < 7; i++) {
        QwtPlotHistogram* histo = new QwtPlotHistogram();
        histo->setStyle(QwtPlotHistogram::Columns);

        QwtColumnSymbol* sym = new QwtColumnSymbol(QwtColumnSymbol::Box);
        if (d[i] > limits[i]) {
            sym->setPalette(Qt::red);
        } else {
            sym->setPalette(QColor(50, 150, 255));
        }
        histo->setSymbol(sym);

        histo->setSamples(QVector<QwtIntervalSample>()
            << QwtIntervalSample(d[i], i, i + 0.7));

        histo->attach(ui->qwtPlot);

        // ===================== 最简单：显示文字 =====================
        if (d[i] > 0) {
            QwtPlotMarker* marker = new QwtPlotMarker;
            marker->setValue(i + 0.35, d[i] + 2);
            marker->setLabel(QString::number(d[i], 'f', 1));
            marker->attach(ui->qwtPlot);
        }

    }

    ui->qwtPlot->replot();
}

void Subwindows::getM702_data(double data[])
{
    for (int i = 0; i < 7; i++)
        m702_datasub[i] = data[i];
}
