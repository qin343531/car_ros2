#ifndef SUBWINDOWS_H
#define SUBWINDOWS_H

#include <QWidget>
#include <qwt_plot_histogram.h>
#include <qwt_column_symbol.h>
#include <qwt_scale_draw.h>
#include <qwt_text.h>
#include <qwt_plot.h>

class MainWindow;

namespace Ui {
class Subwindows;
}

class Subwindows : public QWidget
{
    Q_OBJECT

public:
    explicit Subwindows(QWidget *parent = nullptr);
    MainWindow *mainWin;
    ~Subwindows();

private:
    Ui::Subwindows *ui;
    QwtPlotHistogram *m_histogram; // Qwt 直方图
    // 刷新图表
    void updateChart();

    int count = 0;
};

#endif // SUBWINDOWS_H
