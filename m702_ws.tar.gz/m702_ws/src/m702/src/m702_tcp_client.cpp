#include <rclcpp/rclcpp.hpp>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <stdint.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define FRAME_SIZE 17
#define FRAME_HEADER1 0x3C
#define FRAME_HEADER2 0x02
#define BAUDRATE B9600
#define SERIAL_DEVICE "/dev/ttyUSB0"

#define TCP_SERVER_IP "127.0.0.1"
#define TCP_SERVER_PORT 12346

typedef struct {
    uint16_t eco2;
    uint16_t ech2o;
    uint16_t tvoc;
    uint16_t pm25;
    uint16_t pm10;
    float temperature;
    float humidity;
} M702_Data;

int open_serial(const char *dev, int baudrate)
{
    int fd = open(dev, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("open serial failed");
        return -1;
    }

    struct termios tty;
    if (tcgetattr(fd, &tty) != 0) {
        perror("tcgetattr failed");
        close(fd);
        return -1;
    }

    cfsetospeed(&tty, baudrate);
    cfsetispeed(&tty, baudrate);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_cflag &= ~(PARENB | PARODD);
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;
    tty.c_cflag |= (CLOCAL | CREAD);

    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_oflag &= ~OPOST;

    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 10;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        perror("tcsetattr failed");
        close(fd);
        return -1;
    }

    return fd;
}

int parse_m702_frame(uint8_t *buf, M702_Data *data)
{
    if (buf[0] != FRAME_HEADER1 || buf[1] != FRAME_HEADER2) {
        return -1;
    }

    uint8_t checksum = 0;
    for (int i = 0; i < 16; i++) {
        checksum += buf[i];
    }
    if ((checksum & 0xFF) != buf[16]) {
        return -2;
    }

    data->eco2 = (buf[2] << 8) | buf[3];
    data->ech2o = (buf[4] << 8) | buf[5];
    data->tvoc = (buf[6] << 8) | buf[7];
    data->pm25 = (buf[8] << 8) | buf[9];
    data->pm10 = (buf[10] << 8) | buf[11];

    uint8_t temp_int = buf[12];
    uint8_t temp_dec = buf[13];
    if (temp_int & 0x80) {
        data->temperature = -((temp_int & 0x7F) + temp_dec / 100.0f);
    } else {
        data->temperature = (temp_int + temp_dec / 100.0f);
    }

    uint8_t hum_int = buf[14];
    uint8_t hum_dec = buf[15];
    data->humidity = hum_int + hum_dec / 100.0f;

    return 0;
}

int read_m702_data(int fd, M702_Data *data)
{
    if (fd < 0) {
        return -3;
    }

    uint8_t frame_buf[FRAME_SIZE] = {0};
    ssize_t read_bytes = read(fd, frame_buf, FRAME_SIZE);

    if (read_bytes < 0) {
        if (errno == EAGAIN) {
            return -5;
        }
        return -1;
    }

    if (read_bytes != FRAME_SIZE) {
        return -4;
    }

    int ret = parse_m702_frame(frame_buf, data);
    if (ret != 0) {
        return ret;
    }

    if (data->eco2 == 0 && data->ech2o == 0 && data->tvoc == 0 && data->temperature == 0.0f) {
        return -6;
    }

    return 0;
}

int connect_tcp_server(const char *ip, int port)
{
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket failed");
        return -1;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip, &server_addr.sin_addr) <= 0) {
        perror("inet_pton failed");
        close(sock);
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect failed");
        close(sock);
        return -1;
    }

    return sock;
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("m702_tcp_client");

    std::string serial_device;
    std::string server_ip;
    int server_port;

    node->declare_parameter("serial_device", SERIAL_DEVICE);
    node->declare_parameter("server_ip", TCP_SERVER_IP);
    node->declare_parameter("server_port", TCP_SERVER_PORT);

    node->get_parameter("serial_device", serial_device);
    node->get_parameter("server_ip", server_ip);
    node->get_parameter("server_port", server_port);

    int serial_fd = open_serial(serial_device.c_str(), BAUDRATE);
    if (serial_fd < 0) {
        RCLCPP_ERROR(node->get_logger(), "Failed to open serial device %s", serial_device.c_str());
        return -1;
    }
    RCLCPP_INFO(node->get_logger(), "Opened serial device %s", serial_device.c_str());

    M702_Data m702_data;
    memset(&m702_data, 0, sizeof(M702_Data));

    int tcp_sock = -1;
    bool connected = false;
    int reconnect_interval = 5;
    rclcpp::Rate rate(std::chrono::milliseconds(100));

    while (rclcpp::ok()) {
        if (!connected) {
            tcp_sock = connect_tcp_server(server_ip.c_str(), server_port);
            if (tcp_sock < 0) {
                RCLCPP_WARN(node->get_logger(), "Failed to connect to TCP server %s:%d, retry in %ds",
                         server_ip.c_str(), server_port, reconnect_interval);
                rclcpp::sleep_for(std::chrono::seconds(reconnect_interval));
                continue;
            }
            connected = true;
            RCLCPP_INFO(node->get_logger(), "Connected to TCP server %s:%d", server_ip.c_str(), server_port);
        }

        int ret = read_m702_data(serial_fd, &m702_data);
        if (ret == 0) {
            RCLCPP_INFO(node->get_logger(),
                     "M702 Data - eco2: %u, ech2o: %u, tvoc: %u, pm25: %u, pm10: %u, temp: %.2f, humi: %.2f",
                     m702_data.eco2, m702_data.ech2o, m702_data.tvoc,
                     m702_data.pm25, m702_data.pm10,
                     m702_data.temperature, m702_data.humidity);

            char send_buf[256];
            snprintf(send_buf, sizeof(send_buf),
                     "eco2: %u, ech2o: %u, tvoc: %u, pm25: %u, pm10: %u, temperature: %.2f, humidity: %.2f",
                     m702_data.eco2, m702_data.ech2o, m702_data.tvoc,
                     m702_data.pm25, m702_data.pm10,
                     m702_data.temperature, m702_data.humidity);

            ssize_t sent = send(tcp_sock, send_buf, strlen(send_buf), 0);
            if (sent < 0) {
                perror("send failed");
                close(tcp_sock);
                tcp_sock = -1;
                connected = false;
            } else {
                RCLCPP_DEBUG(node->get_logger(), "Sent: %s", send_buf);
            }
        } else if (ret == -5 || ret == -4) {
        } else if (ret < 0 && ret != -6) {
        }

        rclcpp::sleep_for(std::chrono::seconds(1) / 10);
        rate.sleep();
    }

    if (tcp_sock >= 0) {
        close(tcp_sock);
    }
    close(serial_fd);

    rclcpp::shutdown();
    return 0;
}
